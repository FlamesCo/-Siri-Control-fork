#You can import any required modules here

#This can be anything you want
moduleName = "templateModule"

#All of the words must be heard in order for this module to be executed
commandWords = ["xyz"]

def execute(command):
    #Write anything you want to be executed when the commandWords are heard
    #The 'command' parameter is the command you speak
    return
